tuplex = ("w", 3, "r", "e", "s", "o", "u", "r", "c", "e")

print(tuplex[3])
print(tuplex[-4])