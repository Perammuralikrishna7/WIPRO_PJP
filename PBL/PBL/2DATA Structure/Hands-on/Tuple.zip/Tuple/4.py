tuplex = tuple("Wipro Turbo")
print(tuplex)
#get index of the first item whose value is passed as parameter
index = tuplex.index("p")
print(index)