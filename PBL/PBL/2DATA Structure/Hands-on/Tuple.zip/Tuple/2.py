tuplex = ("w", 3, "r", "e", "s", "o", "u", "r", "c", "e")
print("c" in tuplex)
print(8 in tuplex)