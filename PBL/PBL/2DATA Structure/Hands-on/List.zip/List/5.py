i=5
a=[]
while i>0:
    num=int(input("Enter number: "))
    a.append(num)
    i=i-1
j=5
b=[]
while j>0:
    num=input("Enter number: ")
    a.append(num)
    j=j-1
f=a+b
print("Final list",f)