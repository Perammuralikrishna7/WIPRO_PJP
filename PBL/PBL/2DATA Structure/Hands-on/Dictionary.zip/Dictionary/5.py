d=dict()
for x in range(1,16):
    d[x]=x**2
print(d) 

