d = {'data1':77,'data2':-37,'data3':183}
print(sum(d.values()))