num = set([0, 1, 2, 3, 4, 5])
a=int(input("Enter a number to discard"))
num.discard(a)
print(num)