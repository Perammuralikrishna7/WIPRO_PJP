x = set([1,5])
y = set([5,9])
z = x | y
print(z)