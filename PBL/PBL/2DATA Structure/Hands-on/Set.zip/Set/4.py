A = set([5, 10, 3, 15, 2, 20])

print(max(A))
print(min(A))