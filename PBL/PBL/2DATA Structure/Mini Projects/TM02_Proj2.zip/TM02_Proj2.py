X = map(int, input("Enter a number=").split())    
print(sorted(list(set(X)))[-2])