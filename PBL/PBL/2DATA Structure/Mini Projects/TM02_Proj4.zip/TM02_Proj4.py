

x=input("Enter a text=")
print(x.count('Alex'))
