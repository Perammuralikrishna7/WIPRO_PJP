# -*- coding: utf-8 -*-
"""
Created on Tue Apr 20 11:03:00 2021

@author: ARAVIND
"""

f1=open('sample.txt')
print(f1.read())
f1.close()
