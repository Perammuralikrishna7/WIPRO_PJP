# -*- coding: utf-8 -*-
"""
Created on Tue Apr 20 11:23:35 2021

@author: ARAVIND
"""

with open("sample2.txt") as f:
    lines = []
    for line in f:
        lines.append(line)

print(lines)
