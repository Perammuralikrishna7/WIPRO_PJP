num1=int(input("Enter first number:"))
num2=int(input("Enter second number:"))
if((num1%10)==(num2%10)):
    print("true")
else:
    print("false")