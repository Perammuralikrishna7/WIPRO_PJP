num=int(input("Enter a number:"))
if((num%2)==0):
    print("It is an Even number")
else:
    print("It is an Odd number")