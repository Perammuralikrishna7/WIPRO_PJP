num=int(input("Enter a number:"))
if(num>0):
    print("It is a positive number")
else:
    if(num<0):
        print("It is a negative number")
    else:
        print("It is Zero")