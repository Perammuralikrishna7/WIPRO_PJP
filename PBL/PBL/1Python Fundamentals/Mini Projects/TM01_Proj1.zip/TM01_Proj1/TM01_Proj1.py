num=0.51
print("It costs",0.51*24,"to operate one server per day")
print("It costs",0.51*24*7,"to operate one server per day")
print("It costs",0.51*24*30,"to operate one server per day")
hours=918/0.51
days=hours/24
print(round(days),"Days can be operated one server with $918")