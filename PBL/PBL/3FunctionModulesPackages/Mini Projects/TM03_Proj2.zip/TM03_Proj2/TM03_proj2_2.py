import lmao as cus

name='marcel bentok tanaka'
print(cus.ispalindrome(name))
print("No of vowels: ")
print(cus.count_the_vowels(name))
print("Frequency of letters: ")
print(cus.frequency_of_letters(name))