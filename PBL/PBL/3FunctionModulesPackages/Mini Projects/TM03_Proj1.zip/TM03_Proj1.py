
lst=[n for n in input("Enter colours with hyphen=").split('-')]
lst.sort()
print('-'.join(lst))

