def even(lis):
    for i in lis:
        if i%2 == 0:
            print(i)


list1 = [1,2,3,4,5,6,7,8,9]
even(list1)