from sys import argv

print(argv[0]+" "+argv[1])