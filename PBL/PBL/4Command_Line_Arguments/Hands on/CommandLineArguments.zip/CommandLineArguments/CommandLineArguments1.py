from sys import argv

S = int(argv[1])+int(argv[2])
print("Sum of the numbers is = "+ str(S))